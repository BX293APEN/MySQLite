# MySQLite
sqlite3を扱いやすくするライブラリ
